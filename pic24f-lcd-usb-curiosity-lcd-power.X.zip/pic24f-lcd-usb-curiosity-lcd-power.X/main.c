#include <stddef.h>

#include "power.h"
#include "application/usb_operational_mode.h"
#include "application/battery_operational_mode.h"
#include "mcc_generated_files/rtcc.h"
#include "mcc_generated_files/system.h"
#include "mcc_generated_files/lcd.h"
#include "application/build_time.h"

static void SwitchOperatoinalMode(enum POWER_SOURCE new_source);

static enum POWER_SOURCE current_source;
static const struct OPERATIONAL_MODE *operational_mode;



int main(void)
{
    struct tm build_time;
    
    enum POWER_SOURCE new_source;
    SYSTEM_Initialize();
   
    BUILDTIME_Get(&build_time);
    RTCC_TimeSet(&build_time);
    
    operational_mode = NULL;
    current_source = POWER_SOURCE_UNKNOWN;
    
    new_source = POWER_GetSource();
    
    while(1)
    {
        if(new_source != current_source)
        {
            current_source = new_source;
            SwitchOperatoinalMode(new_source);
        }
        
        do
        {
            operational_mode->Tasks();
            new_source = POWER_GetSource();
            
        } while( current_source == new_source );
    }
    
    return 0;
}

static void SwitchOperatoinalMode(enum POWER_SOURCE new_source)
{
    if(operational_mode != NULL)
    {
        operational_mode->Deinitialize();
    }
    
    switch(new_source)
    {
        case POWER_SOURCE_USB:
            operational_mode = &usb_operational_mode;
            break;

        case POWER_SOURCE_BATTERY:
            operational_mode = &battery_operational_mode;
            break;
            
        default:
            break;
    }
    
    if(operational_mode != NULL)
    {
        operational_mode->Initialize();
    }
}
